//import 'package:firebase_auth/firebase_auth.dart';
//
//class auth{
//  final FirebaseAuth _auth = FirebaseAuth.instance;
//  Future signin() async{
//    try{
//      AuthReu
//    AuthResult result= await _auth.signInAnonymously();
//
//    FirebaseUser user = result.user;
//    return user;
//  }
//  catch(e){
//
//  }}
//
//}