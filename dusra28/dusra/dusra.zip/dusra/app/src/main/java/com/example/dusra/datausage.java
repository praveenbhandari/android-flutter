package com.example.dusra;

import android.graphics.Color;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

import lecho.lib.hellocharts.model.PieChartData;
import lecho.lib.hellocharts.model.SliceValue;
import lecho.lib.hellocharts.view.PieChartView;

public class datausage extends AppCompatActivity {
//String[] uses={"jan","feb","mar"};
  //AnyChartView anyChartView;
//int[] earnings={500,800,2000};
  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_datausage);
    PieChartView pieChartView = findViewById(R.id.chart);

    ArrayList<SliceValue> pieData = new ArrayList<>();
    pieData.add(new SliceValue(70, Color.BLUE).setLabel("DATA USED"));
    pieData.add(new SliceValue(25, Color.GRAY).setLabel("DATA LEFT"));
    pieChartData.setHasLabels(true).setValueLabelTextSize(14);
    pieChartData.setHasCenterCircle(true).setCenterText1("DATA USAGE").setCenterText1FontSize(20).setCenterText1Color(Color.parseColor("#0097A7"));
    PieChartData pieChartData = new PieChartData(pieData);
    pieChartView.setPieChartData(pieChartData);

    }

}

