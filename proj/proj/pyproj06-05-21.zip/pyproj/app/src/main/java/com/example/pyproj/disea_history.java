package com.example.pyproj;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.text.InputType;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.internal.InternalTokenProvider;

import java.util.ArrayList;

public class disea_history extends AppCompatActivity {
SwipeRefreshLayout s;
    CustomList customList;
    ArrayList<Custom_list_data> arrayList = new ArrayList<>();
    ListView lvv;
    FirebaseAuth auth;
    FirebaseFirestore firebaseFirestore;
    CollectionReference ref;
    String m_Text="";
    FloatingActionButton b;int ii=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        super.onBackPressed();
        setContentView(R.layout.activity_disea_history);
        b=findViewById(R.id.bu);
        lvv=findViewById(R.id.hist_list);
        auth=FirebaseAuth.getInstance();
        firebaseFirestore = FirebaseFirestore.getInstance();
        ref = firebaseFirestore.collection("data");
//        Handler h=new Handler();

        past_dataaa();
s=findViewById(R.id.refr);
//        h.postDelayed(new Runnable() {
//            @Override
//            public void run() {
                ii++;
//past_dataaa();
//Log.e("runnable","in runnable:  "+ii++);
//            }
//        },1000);

s.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
    @Override
    public void onRefresh() {
        Log.e("in past data","pasttttt");
        arrayList.clear();
        past_dataaa();
        Log.e("in past data","doneeeee pasttttt");
s.setRefreshing(false);
    }
});



        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(disea_history.this, homepage.class);
                startActivity(i);
            }
        });

//        customList = new CustomList(disea_history.this, arrayList);
//        lvv.setAdapter(customList);

//        arrayList.add(new Custom_list_data(String.valueOf(i + 1), name, "some", "date"));
//        customList = new CustomList(history.this, arrayList);
//        l.setAdapter(customList);


        lvv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
              Log.e("item",""+arrayList.get(position).getSymptoms());
                Log.e("item",""+arrayList.get(position).getName());
                Log.e("item",""+arrayList.get(position).getDate());
                Intent i=new Intent(disea_history.this,disea_details.class);
                i.putExtra("symptomps",arrayList.get(position).getSymptoms());
                i.putExtra("disease",arrayList.get(position).getName());
                i.putExtra("date",arrayList.get(position).getDate());
                i.putExtra("time",arrayList.get(position).getTime());
                Log.e("time",arrayList.get(position).getTime());
                startActivity(i);
//                getdat(position);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch (id){
            case R.id.cont:
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setTitle("Add Or Change Contact Info.");

                final EditText input = new EditText(this);
                input.setInputType(InputType.TYPE_CLASS_PHONE );
                builder.setView(input);

                builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        m_Text = input.getText().toString();
                        ref.document(FirebaseAuth.getInstance().getUid()).update("alt number",m_Text);
                    }
                });
                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });

                builder.show();
                Log.e("textttt is",""+m_Text);
                return true;
            case R.id.out:
                FirebaseAuth.getInstance().signOut();
                Intent i =new Intent(disea_history.this,MainActivity.class);
                startActivity(i);
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    void past_dataaa() {
        ref.document(auth.getUid()).collection("disease").orderBy("time", Query.Direction.ASCENDING).get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()) {
                    QuerySnapshot queryDocumentSnapshots = task.getResult();
                    Log.e("getting", "recent symptomps" + queryDocumentSnapshots.getDocuments().size());


                    for (int i = 0; i < queryDocumentSnapshots.getDocuments().size(); i++) {
                        try {
                            Log.e("data", queryDocumentSnapshots.getDocuments().get(i).get("symptoms").toString());
                            String date = queryDocumentSnapshots.getDocuments().get(i).get("date").toString();
                            String time = queryDocumentSnapshots.getDocuments().get(i).get("time").toString();
                            String symp = queryDocumentSnapshots.getDocuments().get(i).get("symptoms").toString();
                            String dis_his = queryDocumentSnapshots.getDocuments().get(i).get("disease").toString();
                            Log.e("data", "adding in list");
                            arrayList.add(new Custom_list_data(String.valueOf(i + 1), dis_his, symp, date, time));
                        }
                        catch(Exception e){
                            Log.e("Exception",""+e);

                        }
                        //                        recent_uid.add(p_uid);
//                        symp.add(queryDocumentSnapshots.getDocuments().get(i).get("symptoms").toString());
                    }
//                    listView.setAdapter(a);
                    Log.e("data", "adding in list" + arrayList);
                    customList = new CustomList(disea_history.this, arrayList);
                    lvv.setAdapter(customList);
                } else {
                    Toast.makeText(disea_history.this, "Erorr getting patient histoery", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

}