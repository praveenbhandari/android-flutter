package com.example.pyproj;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class webv extends AppCompatActivity {
WebView web;
Bundle b;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_webv);

        web=findViewById(R.id.web  );
        b=getIntent().getExtras();
        String d= b.getString("disease");
        Log.e("datttttt",""+d);
        web.setWebViewClient(new WebViewClient());
        web.getSettings().setUseWideViewPort(true);
        web.getSettings().setLoadWithOverviewMode(true);
        web.loadUrl("https://www.mayoclinic.org/search/search-results?q="+d);
//        web.find
    }
}