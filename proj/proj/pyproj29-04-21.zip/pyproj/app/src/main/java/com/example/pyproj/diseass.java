package com.example.pyproj;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.os.Bundle;
import android.view.MenuItem;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class diseass extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        BottomNavigationView bottomNva=findViewById(R.id.bottom_navigation);
        bottomNva.setOnNavigationItemSelectedListener(navListener);
    }
    private BottomNavigationView.OnNavigationItemSelectedListener navListener=
            new BottomNavigationView.OnNavigationItemSelectedListener(){
                @Override
                public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                    Fragment selectedFragment=null;
                    switch (item.getItemId()){
                        case R.id.overview:
                            selectedFragment = new overview();
                            break;
                        case R.id.symptoms:
                            selectedFragment = new sympto();
                            break;
                        case R.id.treatment:
                            selectedFragment = new treatment();
                            break;
                        case R.id.specialists:
                            selectedFragment = new speciality();
                            break;

                    }
                    getSupportFragmentManager().beginTransaction().replace(R.id.fragemntcontainer,
                            selectedFragment).commit();
                    return true;
                }
            };
}
