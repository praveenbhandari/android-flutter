package com.example.hadop;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class recent_patients extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recent_patients);
    }
}