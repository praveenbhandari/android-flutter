package com.example.pyproj;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;

public class disea_history extends AppCompatActivity {

    CustomList customList;
    ArrayList<Custom_list_data> arrayList = new ArrayList<>();
    ListView lvv;
    FirebaseAuth auth;
    FirebaseFirestore firebaseFirestore;
    CollectionReference ref;
    Button b;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        super.onBackPressed();
        setContentView(R.layout.activity_disea_history);
        b=findViewById(R.id.bu);
        lvv=findViewById(R.id.hist_list);
        auth=FirebaseAuth.getInstance();
        firebaseFirestore = FirebaseFirestore.getInstance();
        ref = firebaseFirestore.collection("data");
        past_dataaa();
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(disea_history.this, homepage.class);
                startActivity(i);
            }
        });

        customList = new CustomList(disea_history.this, arrayList);
        lvv.setAdapter(customList);

//        arrayList.add(new Custom_list_data(String.valueOf(i + 1), name, "some", "date"));
//        customList = new CustomList(history.this, arrayList);
//        l.setAdapter(customList);
    }



    void past_dataaa() {
        ref.document(auth.getUid()).collection("disease").get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()) {
                    QuerySnapshot queryDocumentSnapshots = task.getResult();
                    Log.e("getting", "recent symptomps" + queryDocumentSnapshots.getDocuments().size());


                    for (int i = 0; i < queryDocumentSnapshots.getDocuments().size(); i++) {
                        Log.e("data", queryDocumentSnapshots.getDocuments().get(i).get("symptoms").toString());
                        String time = queryDocumentSnapshots.getDocuments().get(i).get("time").toString();
                        String symp = queryDocumentSnapshots.getDocuments().get(i).get("symptoms").toString();
                        String dis_his = queryDocumentSnapshots.getDocuments().get(i).get("disease").toString();
                        Log.e("data", "adding in list");
                        arrayList.add(new Custom_list_data(String.valueOf(i + 1), dis_his, symp, time));
//                        recent_uid.add(p_uid);
//                        symp.add(queryDocumentSnapshots.getDocuments().get(i).get("symptoms").toString());
                    }
//                    listView.setAdapter(a);
                    Log.e("data", "adding in list" + arrayList);
                    customList = new CustomList(disea_history.this, arrayList);
                    lvv.setAdapter(customList);
                } else {
                    Toast.makeText(disea_history.this, "Erorr getting patient histoery", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

}