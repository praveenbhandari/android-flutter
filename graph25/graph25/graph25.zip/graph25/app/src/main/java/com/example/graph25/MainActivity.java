package com.example.graph25;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.utils.ColorTemplate;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
TextView a;
BarChart bar;
TextView bb;
public Integer data1;
    public Integer data2;
    public Integer data3;
    public Integer data4;
    public Integer counter;
public Float val;
    public Float val1;
    public Float val2;
    public Float val3;
    public Float val4;
DatabaseReference ref;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        a=(TextView)findViewById(R.id.text1);
        bb=(TextView)findViewById(R.id.bb);
        bar=(BarChart)findViewById(R.id.bar1);


              ref= FirebaseDatabase.getInstance().getReference().child("graph");
              ref.addValueEventListener(new ValueEventListener() {
                  @Override
                  public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                      data1= (Integer) dataSnapshot.child("Data1").getValue();

                      data2= (Integer) dataSnapshot.child("Data2").getValue();

                      data3= (Integer) dataSnapshot.child("Data3").getValue();

                      data4= (Integer) dataSnapshot.child("Data4").getValue();



                      counter= (Integer) dataSnapshot.child("Counter").getValue();

                  }

                  @Override
                  public void onCancelled(@NonNull DatabaseError databaseError) {


                  }

              });
              int i=0;
        ArrayList<BarEntry> barEntries = new ArrayList<>();
        barEntries.add(new BarEntry(i+1, 89f));
        barEntries.add(new BarEntry(i+2, 20f));
        barEntries.add(new BarEntry(i+3, 50f));
        barEntries.add(new BarEntry(i+4, 10f));

        BarDataSet barDataSet=new BarDataSet(barEntries,"Data set");
        barDataSet.setColors(ColorTemplate.COLORFUL_COLORS);
        BarData data=new BarData(barDataSet);
        bar.setData(data);
          }

        }
